# analyze_logs.awk - SSH brute-force analysis (POSIX awk: works with mawk and gawk)
# Input : cleaned log produced by sed/clean_logs.sed
#         fields:  $1 time  $2 EVENT  $3 user=NAME  $4 ip=ADDRESS
# Usage : awk -f awk/analyze_logs.awk -v mode=ips|users|success|summary \
#             -v threshold=5 -v window=300 -v user_threshold=3 -v repeat_fail=3 cleaned_log.txt

function to_sec(t,   p) { split(t, p, ":"); return p[1] * 3600 + p[2] * 60 + p[3] }

# largest number of failures from one IP inside any 'window'-second interval
function max_in_window(ip,   i, j, best) {
    best = 0; j = 1
    for (i = 1; i <= nfail[ip]; i++) {
        while (ft[ip, i] - ft[ip, j] > window) j++
        if (i - j + 1 > best) best = i - j + 1
    }
    return best
}

BEGIN {
    if (threshold == "")      threshold = 5
    if (window == "")         window = 300
    if (user_threshold == "") user_threshold = 3
    if (repeat_fail == "")    repeat_fail = 3
}

{
    ev = $2
    split($3, u, "="); user = u[2]
    split($4, a, "="); ip = a[2]
    sec = to_sec($1)

    if (ev == "FAILED" || ev == "FAILED_INVALID") {
        nfail[ip]++; ft[ip, nfail[ip]] = sec
        total_fail++; ucount[user]++; ips[ip] = 1
        if (ev == "FAILED_INVALID") total_invalid++
        if (!((ip, user) in seen)) { seen[ip, user] = 1; nusers[ip]++ }
    } else if (ev == "ACCEPTED") {
        nacc[ip]++; total_acc++; ips[ip] = 1
        n_acc_events++
        a_ip[n_acc_events] = ip; a_user[n_acc_events] = user
        nf = (ip in nfail) ? nfail[ip] : 0      # avoid creating empty entries in nfail[]
        a_time[n_acc_events] = $1; a_prior[n_acc_events] = nf
        r = 0
        for (i = 1; i <= nf; i++) if (sec - ft[ip, i] <= window) r++
        a_recent[n_acc_events] = r
    }
}

END {
    if (mode == "ips") {                       # ip failures users max_in_window accepted flags
        for (ip in ips) {
            if (nfail[ip] == 0) continue
            m = max_in_window(ip); flags = ""
            if (m >= threshold) flags = "BURST"
            if (nusers[ip] >= user_threshold) flags = (flags == "" ? "MULTIUSER" : flags ",MULTIUSER")
            if (flags == "") flags = "-"
            print ip, nfail[ip], nusers[ip], m, nacc[ip] + 0, flags
        }
    } else if (mode == "users") {              # username failed_attempts
        for (x in ucount) print x, ucount[x]
    } else if (mode == "success") {            # time ip user prior_failures failures_in_window
        for (k = 1; k <= n_acc_events; k++)
            if (a_prior[k] >= repeat_fail)
                print a_time[k], a_ip[k], a_user[k], a_prior[k], a_recent[k]
    } else if (mode == "summary") {
        n = 0; for (ip in nfail) n++
        print "failed_total", total_fail + 0
        print "failed_invalid", total_invalid + 0
        print "accepted_total", total_acc + 0
        print "ips_with_failures", n
    }
}
