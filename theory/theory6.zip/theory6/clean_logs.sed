# clean_logs.sed - normalise SIMULATED sshd authentication records
# Usage: sed -E -f sed/clean_logs.sed logs/ssh_auth.log > output/cleaned_log.txt
# Result: "HH:MM:SS EVENT user=NAME ip=ADDRESS"

# 1. remove the comment/header lines of the dataset
/^#/d
# 2. keep only records written by sshd
/sshd\[[0-9]+\]:/!d
# 3. drop events that are not authentication attempts
/Server listening|Disconnected from|Connection closed/d
# 4. remove the hostname and sshd[PID] prefix (the time of day is kept)
s/^([0-9:]{8}) [^ ]+ sshd\[[0-9]+\]: /\1 /
# 5. remove the unneeded port / protocol fields
s/ port [0-9]+( ssh2)?$//
# 6. convert each message into EVENT user= ip= fields
s/Failed password for invalid user ([^ ]+) from ([^ ]+)$/FAILED_INVALID user=\1 ip=\2/
s/Failed password for ([^ ]+) from ([^ ]+)$/FAILED user=\1 ip=\2/
s/Accepted password for ([^ ]+) from ([^ ]+)$/ACCEPTED user=\1 ip=\2/
s/Invalid user ([^ ]+) from ([^ ]+)$/INVALID_USER user=\1 ip=\2/
