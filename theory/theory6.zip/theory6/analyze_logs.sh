#!/bin/bash
# analyze_logs.sh - SSH brute-force investigation # Usage: ./scripts/analyze_logs.sh [path/to/ssh_auth.log]

# ---------- variables and thresholds ----------
BASE_DIR="${BASE_DIR:-/home/msis/cyber_log_analysis}"
LOG_FILE="${1:-$BASE_DIR/logs/ssh_auth.log}"
OUT_DIR="$BASE_DIR/output"
SED_SCRIPT="$BASE_DIR/sed/clean_logs.sed"
AWK_SCRIPT="$BASE_DIR/awk/analyze_logs.awk"
CLEAN="$OUT_DIR/cleaned_log.txt"
THRESHOLD=5          # failures from one IP ...
WINDOW=300           # ... inside this many seconds (5 minutes)
USER_THRESHOLD=3     # distinct usernames tried from one IP
REPEAT_FAIL=3        # failures before a success counts as "repeated"

# ---------- functions ----------
section() { echo; echo "=== $1 ==="; }
die()     { echo "ERROR: $1" >&2; exit 1; }
run_awk() {          # run_awk MODE  -> runs the separate awk script on the cleaned log
    awk -f "$AWK_SCRIPT" -v mode="$1" -v threshold="$THRESHOLD" -v window="$WINDOW" \
        -v user_threshold="$USER_THRESHOLD" -v repeat_fail="$REPEAT_FAIL" "$CLEAN"
}

# ---------- 1. input checks and output directory ----------
for f in "$LOG_FILE" "$SED_SCRIPT" "$AWK_SCRIPT"; do
    [[ -f "$f" ]] || die "required file not found: $f"
done
mkdir -p "$OUT_DIR"
echo "SSH LOG ANALYSIS (simulated dataset - not a real incident)"
echo "Input log : $LOG_FILE"
echo "Output dir: $OUT_DIR"

# ---------- 2. basic counts (grep + command substitution) ----------
TOTAL_LINES=$(wc -l < "$LOG_FILE")
RECORDS=$(grep -vc '^#' "$LOG_FILE")
FAILED=$(grep -c "Failed password" "$LOG_FILE")
ACCEPTED=$(grep -c "Accepted password" "$LOG_FILE")
INVALID=$(grep -c "Invalid user" "$LOG_FILE")
section "1. LOG OVERVIEW"
printf "%-34s %s\n" "Total lines in file:" "$TOTAL_LINES"
printf "%-34s %s\n" "Log records (comments excluded):" "$RECORDS"
printf "%-34s %s\n" "Failed password attempts:" "$FAILED"
printf "%-34s %s\n" "Successful (accepted) logins:" "$ACCEPTED"
printf "%-34s %s\n" "Invalid-username attempts:" "$INVALID"

# invalid usernames, extracted with sed and ranked with a pipeline
grep "Invalid user" "$LOG_FILE" | sed -E 's/.*Invalid user ([^ ]+) from.*/\1/' \
    | sort | uniq -c | sort -k1,1nr -k2,2 | awk '{print $2, $1}' > "$OUT_DIR/invalid_usernames.txt"

# ---------- 3. clean the log with the separate sed script ----------
sed -E -f "$SED_SCRIPT" "$LOG_FILE" > "$CLEAN"
CLEAN_LINES=$(wc -l < "$CLEAN")
printf "%-34s %s\n" "Cleaned authentication events:" "$CLEAN_LINES"

# ---------- 4. per-IP statistics with the separate awk script ----------
run_awk ips | sort -k2,2nr -k1,1 > "$OUT_DIR/ip_analysis.txt"
awk '{printf "%d %s %s\n", NR, $1, $2}' "$OUT_DIR/ip_analysis.txt" > "$OUT_DIR/failed_by_ip.txt"
section "2. SOURCE IPs RANKED BY FAILED LOGINS (top 5)"
printf "%-5s %-18s %s\n" "RANK" "SOURCE IP" "FAILED"
head -n 5 "$OUT_DIR/failed_by_ip.txt" | while read -r rank ip count; do
    printf "%-5s %-18s %s\n" "$rank" "$ip" "$count"
done

# ---------- 5. targeted usernames ----------
run_awk users | sort -k2,2nr -k1,1 > "$OUT_DIR/usernames_targeted.txt"
section "3. MOST TARGETED USERNAMES (top 5)"
printf "%-14s %s\n" "USERNAME" "FAILED"
head -n 5 "$OUT_DIR/usernames_targeted.txt" | while read -r user count; do
    printf "%-14s %s\n" "$user" "$count"
done

# ---------- 6. IPs exceeding the thresholds ----------
awk '$6 != "-"' "$OUT_DIR/ip_analysis.txt" > "$OUT_DIR/suspicious_ips.txt"
section "4. IPs EXCEEDING THRESHOLDS (>=$THRESHOLD fails in ${WINDOW}s or >=$USER_THRESHOLD usernames)"
if [[ -s "$OUT_DIR/suspicious_ips.txt" ]]; then
    printf "%-18s %6s %6s %9s %-18s\n" "SOURCE IP" "FAILED" "USERS" "MAX/5MIN" "FLAGS"
    while read -r ip fails users maxwin acc flags; do
        printf "%-18s %6s %6s %9s %-18s\n" "$ip" "$fails" "$users" "$maxwin" "$flags"
    done < "$OUT_DIR/suspicious_ips.txt"
else
    echo "No IP address exceeded the thresholds."
fi

# ---------- 7. success after repeated failures ----------
run_awk success > "$OUT_DIR/success_after_failures.txt"
section "5. SUCCESSFUL LOGINS AFTER >=$REPEAT_FAIL FAILURES FROM THE SAME IP"
if [[ -s "$OUT_DIR/success_after_failures.txt" ]]; then
    printf "%-9s %-16s %-9s %7s %8s  %s\n" "TIME" "SOURCE IP" "USER" "PRIOR" "LAST5MIN" "ASSESSMENT"
    while read -r time ip user prior recent; do
        if (( recent >= THRESHOLD )); then verdict="HIGH: burst before login"
        else verdict="REVIEW: slow failures"; fi
        printf "%-9s %-16s %-9s %7s %8s  %s\n" "$time" "$ip" "$user" "$prior" "$recent" "$verdict"
    done < "$OUT_DIR/success_after_failures.txt"
else
    echo "None found."
fi

# ---------- 8. drill-down loop over every flagged IP ----------
section "6. ACTIVITY WINDOW OF FLAGGED IPs"
printf "%-18s %-9s %-9s %s\n" "SOURCE IP" "FIRST" "LAST" "ACCEPTED LOGIN?"
for ip in $(cut -d' ' -f1 "$OUT_DIR/suspicious_ips.txt"); do
    first=$(grep "Failed password.* from $ip " "$LOG_FILE" | head -n 1 | cut -c1-8)
    last=$(grep "Failed password.* from $ip " "$LOG_FILE" | tail -n 1 | cut -c1-8)
    if grep -q "Accepted password.* from $ip " "$LOG_FILE"; then ok="yes"; else ok="no"; fi
    printf "%-18s %-9s %-9s %s\n" "$ip" "$first" "$last" "$ok"
done

# ---------- 9. final investigation summary ----------
N_SUSP=$(wc -l < "$OUT_DIR/suspicious_ips.txt")
N_SUCC=$(wc -l < "$OUT_DIR/success_after_failures.txt")
TOP_IP=$(head -n 1 "$OUT_DIR/failed_by_ip.txt" | cut -d' ' -f2)
TOP_COUNT=$(head -n 1 "$OUT_DIR/failed_by_ip.txt" | cut -d' ' -f3)
TOP_USER=$(head -n 1 "$OUT_DIR/usernames_targeted.txt" | cut -d' ' -f1)
{
    echo "INVESTIGATION SUMMARY (simulated dataset - not a real incident)"
    echo "Generated : $(date '+%H:%M:%S') (time of day only)"
    echo "Log file  : $LOG_FILE"
    echo "Thresholds: >=$THRESHOLD failures in ${WINDOW}s, >=$USER_THRESHOLD usernames, >=$REPEAT_FAIL failures before success"
    echo "----------------------------------------------------------------"
    echo "Log records analysed      : $RECORDS"
    echo "Failed / accepted / invalid: $FAILED / $ACCEPTED / $INVALID"
    echo "Top source IP             : $TOP_IP ($TOP_COUNT failures)"
    echo "Most targeted username    : $TOP_USER"
    echo "IPs flagged by thresholds : $N_SUSP"
    echo "Success after failures    : $N_SUCC event(s) need further investigation"
    echo "Note: a flag means 'review', not 'malicious' (see false positives)."
} > "$OUT_DIR/summary_report.txt"
section "7. FINAL SUMMARY"
cat "$OUT_DIR/summary_report.txt"
echo
echo "Result files saved in $OUT_DIR:"
ls "$OUT_DIR"
