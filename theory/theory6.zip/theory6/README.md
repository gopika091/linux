# Cybersecurity Log Analysis Using Linux Tools

**Student:** GOPIKASHREE K R  |  **Register No.:** 261100690031



## 1\. Objective

Investigate an SSH authentication log with Linux power filters (grep, sort, uniq, wc, head, tail, cut), Bash
scripting, sed and awk to detect brute-force login behaviour: repeated failures, noisy IP addresses, many
usernames from one IP, successful logins after repeated failures, and bursts of failures in a short time.

## 2\. Selected scenario

SSH Authentication Log Analysis - Detecting Brute-Force Login Attempts.

## 3\. Dataset creation

`scripts/generate\\\\\\\_ssh\\\\\\\_log.sh` writes `logs/ssh\\\\\\\_auth.log` (94 lines, format similar to Kali/Debian
`/var/log/auth.log`). It contains normal logins, occasional typing mistakes, a user who forgot a password, a fast
brute-force with a later successful login, password guessing against `root`, slow multi-username probing and a
below-threshold case. Details are in `logs/DATASET\\\\\\\_INFO.md`.

## 4\. Directory structure (`/home/msis/cyber\\\\\\\_log\\\\\\\_analysis/`)

```
logs/         ssh\\\\\\\_auth.log (simulated), DATASET\\\\\\\_INFO.md
scripts/      generate\\\\\\\_ssh\\\\\\\_log.sh, analyze\\\\\\\_logs.sh
sed/          clean\\\\\\\_logs.sed
awk/          analyze\\\\\\\_logs.awk
output/       results written by analyze\\\\\\\_logs.sh
screenshots/  terminal screenshots used in the report
report/       Cybersecurity\\\\\\\_Log\\\\\\\_Analysis\\\\\\\_Assignment.docx
README.md
```

## 5\. Required tools

bash, grep, sort, uniq, wc, head, tail, cut, less, sed (GNU), awk (mawk or gawk). All are installed in Kali Linux.

## 6\. How to run

```bash
cd /home/msis/cyber\\\\\\\_log\\\\\\\_analysis
chmod +x scripts/\\\\\\\*.sh
./scripts/generate\\\\\\\_ssh\\\\\\\_log.sh        # creates logs/ssh\\\\\\\_auth.log
./scripts/analyze\\\\\\\_logs.sh            # runs sed + awk + bash analysis, writes output/
```

Run the separate scripts by hand:

```bash
sed -E -f sed/clean\\\\\\\_logs.sed logs/ssh\\\\\\\_auth.log > output/cleaned\\\\\\\_log.txt
awk -f awk/analyze\\\\\\\_logs.awk -v mode=ips     output/cleaned\\\\\\\_log.txt | sort -k2,2nr
awk -f awk/analyze\\\\\\\_logs.awk -v mode=users   output/cleaned\\\\\\\_log.txt | sort -k2,2nr
awk -f awk/analyze\\\\\\\_logs.awk -v mode=success output/cleaned\\\\\\\_log.txt
awk -f awk/analyze\\\\\\\_logs.awk -v mode=summary output/cleaned\\\\\\\_log.txt
```

## 7\. Inspecting the results

```bash
ls -l output/
cat output/summary\\\\\\\_report.txt
cat output/suspicious\\\\\\\_ips.txt output/success\\\\\\\_after\\\\\\\_failures.txt
head -n 15 output/cleaned\\\\\\\_log.txt
```

Output files: `cleaned\\\\\\\_log.txt`, `failed\\\\\\\_by\\\\\\\_ip.txt`, `ip\\\\\\\_analysis.txt`, `invalid\\\\\\\_usernames.txt`,
`usernames\\\\\\\_targeted.txt`, `suspicious\\\\\\\_ips.txt`, `success\\\\\\\_after\\\\\\\_failures.txt`, `summary\\\\\\\_report.txt`.

## 8\. Suspicious-activity thresholds

|Rule|Value|Reason|
|-|-|-|
|BURST|5 or more failures from one IP within 300 s|Faster than normal human typing mistakes|
|MULTIUSER|3 or more different usernames from one IP|One person rarely tries many accounts|
|Success after failures|3 or more earlier failures from the same IP|Possible guessed password - needs review|
|The values are variables at the top of `scripts/analyze\\\\\\\_logs.sh` and can be changed.|||



